/*
** File: usage.h
**
** Copyright 2006 Mark Lisee
**
*/

#ifndef	_usage_h_
#define _usage_h_

void printUsage( const char *pName, const char *usageString);

#endif	// _usage_h_

/* end file usage.h */
